int f(int x, int y);

int main() {
	f(2, 5);
}