#include <iostream>
using namespace std;

int f(int x, int y);

int main() {
	int n = f(2, 5);
	cout << n;
}