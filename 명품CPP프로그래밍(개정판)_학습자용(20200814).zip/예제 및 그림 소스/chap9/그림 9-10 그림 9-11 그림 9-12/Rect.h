#ifndef RECT
#define RECT

class Rect : public Shape {
protected:
	virtual void draw();
};

#endif