#ifndef GRAPHICMANAGER
#define GRAPHICMANAGER

class GraphicManager {
	void prompt();
	int readShape();
public:
	GraphicManager();
	void run();
};

#endif