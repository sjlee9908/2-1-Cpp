namespace mike {
	int f();
	int g();
}