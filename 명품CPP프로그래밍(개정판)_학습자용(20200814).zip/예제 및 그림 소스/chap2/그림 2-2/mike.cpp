namespace mike {
	int f() {
		return -1;
	}
	int g() {
		return 0;
	}
}