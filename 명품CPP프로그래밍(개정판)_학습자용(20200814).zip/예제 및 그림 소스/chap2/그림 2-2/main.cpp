#include "kitae.h"
#include "mike.h"

int main() {
	kitae::m();
	mike::g();
}