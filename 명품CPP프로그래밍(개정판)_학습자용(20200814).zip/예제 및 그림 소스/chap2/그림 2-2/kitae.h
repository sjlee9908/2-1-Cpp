namespace kitae {
	int f();
	void m();
}