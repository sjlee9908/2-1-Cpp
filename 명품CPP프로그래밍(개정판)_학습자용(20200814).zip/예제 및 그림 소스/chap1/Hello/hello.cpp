#include <iostream>

int main() {
	std::cout << "Hello";
	return 0;
}