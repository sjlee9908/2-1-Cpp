#include "CircleVectorManager.h"

int main() {
	CircleVectorManager cvm;
	cvm.run();
}