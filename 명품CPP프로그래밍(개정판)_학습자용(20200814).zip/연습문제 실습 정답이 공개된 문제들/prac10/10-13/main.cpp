#include "Grade.h"

int main() {
	GradeManager gm("HIGH SCORE");
	gm.run();
}