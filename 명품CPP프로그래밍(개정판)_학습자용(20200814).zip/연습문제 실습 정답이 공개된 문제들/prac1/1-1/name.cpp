#include <iostream>

int main() {
	std::cout << "My name is Mike.\n";
	return 0;
}